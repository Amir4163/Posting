﻿using System.Windows.Controls;

namespace PostProject
{
    public partial class EmptyWin : UserControl
    {
        public EmptyWin()
        {
            InitializeComponent();
        }
    }
}
